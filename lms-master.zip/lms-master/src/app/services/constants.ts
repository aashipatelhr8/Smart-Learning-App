export const Constants = Object.freeze({
    'WALKTHROUGHT': 'Walkthrought',
    'SIGNUP': 'Signup',
    'SOCIAL': 'Social',
    'PROFILE': 'Profile',
    'MEDIA': 'Media',
    'E_COMMERCE': 'E-Commerce',
    'HOME': 'Home',
    'BROWSER': 'Browser',
    'Courses': 'Courses',
    'INFO': 'Info',
    
});