export class MenuItem {
    id: number;
    counter: number
    name: string;
    type: string;
    data: any;
    events: any;

   constructor(id: number, title: string, counter:number, type:string) {
        this.id =  id;
        this.name = title;
        this.counter = counter;
        this.type = type;
    }

    getUrl() {
        return `${this.type.toLowerCase()}/${this.id-1}`;
    }
}