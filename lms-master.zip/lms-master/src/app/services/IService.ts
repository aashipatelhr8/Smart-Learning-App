import { MenuItem } from './MenuItem';
import { Observable } from 'rxjs';

export interface IService {
  getMenuList(): Array<MenuItem>;
  load(menuItem: MenuItem): Observable<any>;
  loadEvents(menuItem: MenuItem): any;
}
