import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vplayer',
  templateUrl: './vplayer.component.html',
  styleUrls: ['./vplayer.component.scss'],
})
export class VplayerComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
