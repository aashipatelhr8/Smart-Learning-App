import { Component } from '@angular/core';
import { NavController } from '@ionic/angular';
import { HomeService } from '../../services/home-service';

@Component({
  selector: 'home-page',
  templateUrl: 'home-page.page.html',
  styleUrls: ['home-page.page.scss'],
  providers: [HomeService]
})
export class HomePage {
  data: {
    'headerImage': '',
    'title': '',
    'contentImage': '',
    'btnDiscover': '',
    'btnPurchase': ''
  }
  constructor(public navCtrl: NavController, private homeService: HomeService) {
    this.homeService.load().subscribe(it => this.data = it)
  }
}
