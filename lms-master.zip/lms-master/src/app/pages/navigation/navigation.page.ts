import { Component } from '@angular/core';
import { NavController } from '@ionic/angular';
import { MenuItem } from '../../services/MenuItem';
import { Constants } from '../../services/constants';
import { ToastService } from '../../services/toast-service';
import { ActivatedRoute } from '@angular/router';
import { IService } from '../../services/IService';
import { WalkthroughService } from '../../services/walkthrough-service';
import { SignUpService } from '../../services/signup-service';
import { SocialService } from '../../services/social-service';
import { ProfileService } from '../../services/profile-service';
import { MediaService } from '../../services/media-service';
import { EcommerceService } from '../../services/ecommerce-service';

/**
 * Generated class for the NavigationPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@Component({
  selector: 'page-navigation',
  templateUrl: 'navigation.page.html',
  styleUrls: ['navigation.page.scss'],
  providers: [
    WalkthroughService, SignUpService, SocialService,
    ProfileService, MediaService, EcommerceService
  ]
})

export class NavigationPage {
  service: IService;
  type: String = ""
  listMenu: Array<MenuItem>
  listServices: { [key: string]: IService; } = {};

  constructor(
    public toastCtrl: ToastService,
    private route: ActivatedRoute,
    private navController: NavController,
    private walkthroughService: WalkthroughService,
    private signUpService: SignUpService,
    private socialService: SocialService,
    private profileService: ProfileService,
    private mediaService: MediaService,
    private ecommerceService: EcommerceService) {

    this.type = this.route.snapshot.paramMap.get('type');

    switch (this.type) {
      case Constants.WALKTHROUGHT:
        this.service = this.walkthroughService;
        break;
      case Constants.SIGNUP:
        this.service = this.signUpService;
        break;
      case Constants.SOCIAL:
        this.service = this.socialService;
        break;
      case Constants.PROFILE:
        this.service = this.profileService;
        break;
      case Constants.MEDIA:
        this.service = this.mediaService;
        break;
      case Constants.E_COMMERCE:
        this.service = this.ecommerceService;
        break;
    }
    this.listMenu = this.service.getMenuList()
  }

  openPage(page) {
    this.navController.navigateForward([page.getUrl()], {});
  }
}
