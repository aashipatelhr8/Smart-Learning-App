import { Component } from '@angular/core';
import { NavController } from '@ionic/angular';
import { ActivatedRoute } from '@angular/router';
import { ToastService } from 'src/app/services/toast-service';
import { WalkthroughService } from './../../services/walkthrough-service';

/**
 * Generated class for the WalkthroughtPage page.
 *
 * See https://ionicframework.com/docs/components/#navigation for more info on
 * Ionic pages and navigation.
 */

@Component({
  selector: 'page-walkthrought',
  templateUrl: 'walkthrought.page.html',
  styleUrls: ['walkthrought.page.scss'],
  providers: [WalkthroughService]
})
export class WalkthroughtPage {

  data = {};
  type: string;

  constructor(
    public navCtrl: NavController,
    private service: WalkthroughService,
    private toastCtrl: ToastService,
    private route: ActivatedRoute) {
    this.type = this.route.snapshot.paramMap.get('type');
    let menuItem = service.getMenuList()[this.type]
    this.service.load(menuItem).subscribe(d => {
      this.data = d;
    });
  }

  isType(item) {
    return item === parseInt(this.type, 10);
  }

  onPrevious(params) {
    this.toastCtrl.presentToast('onPrevious');
  }

  onNext(params) {
    this.toastCtrl.presentToast('onNext');
  }

  onFinish(params) {
    this.toastCtrl.presentToast('onFinish');
  }

  onGetStarted(params) {
    this.toastCtrl.presentToast('onGetStarted');
  }
}
