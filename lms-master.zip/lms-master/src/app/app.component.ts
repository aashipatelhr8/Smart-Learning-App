import { Component, OnInit } from '@angular/core';
import { Platform } from '@ionic/angular';
import { SplashScreen } from '@ionic-native/splash-screen/ngx';
import { StatusBar } from '@ionic-native/status-bar/ngx';
import { NavController } from '@ionic/angular';
import { MenuItem } from './services/MenuItem';
import { Constants } from './services/constants';
import { ExportService } from './services/export';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
  providers: [ExportService]
})
export class AppComponent {
  pages = [];

  // firstTime : boolean = true;

  constructor(
    private platform: Platform,
    private splashScreen: SplashScreen,
    private statusBar: StatusBar,
    private navController: NavController,
    private exportService: ExportService
  ) {
    this.initializeApp();
  }


  // ngOnInit(){
  //   // get firstTime value from storage
  //   // if(this.firstTime == true){
  //   //   // store false in storage service;
  //   //   this.navController.navigateForward("walkthrough");
  //   // }  
  // }

  getMenuList(): MenuItem[] {
    var menuItemList = [];
    menuItemList.push(new MenuItem(1, Constants.HOME, 1, Constants.HOME));
    menuItemList.push(new MenuItem(2, Constants.BROWSER, 3, Constants.BROWSER));
    menuItemList.push(new MenuItem(3, Constants.Courses, 10, Constants.Courses));
    menuItemList.push(new MenuItem(4, Constants.INFO, 5, Constants.INFO));
    return menuItemList;
  }

  initializeApp() {
    // console.log(JSON.stringify(this.exportService.export()))
    this.platform.ready().then(() => {
      this.statusBar.overlaysWebView(false);
      this.statusBar.backgroundColorByHexString('#0091D2');
      this.pages = this.getMenuList();
    });
  }

  openPage(page) {
    this.navController.navigateRoot([`items/${page.type}`], {});
  }
}
