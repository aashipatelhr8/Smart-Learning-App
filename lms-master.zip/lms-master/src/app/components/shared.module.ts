import { Walkthrought1 } from './walkthrought/walkthrought-1/walkthrought-1.page';
import { NgModule, CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { IonicModule } from '@ionic/angular';
import { TabComponent } from './tab/tab.component';
import { FeaturedCoursesComponent } from './featured-courses/featured-courses.component';
import { SubjectsComponent } from './subjects/subjects.component';
import { HomeTopSliderComponent } from './home-top-slider/home-top-slider.component';
import { Browser } from 'protractor';
import { SearchbarComponent } from './searchbar/searchbar.component';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    // AgmCoreModule.forRoot({ apiKey: 'AIzaSyA4-GoZzOqYTvxMe52YQZch5JaCFN6ACLg' })
  ],
  declarations: [
 Walkthrought1,FeaturedCoursesComponent,SubjectsComponent,HomeTopSliderComponent,SearchbarComponent
  ],
  exports: [
 Walkthrought1,FeaturedCoursesComponent,SubjectsComponent,HomeTopSliderComponent,SearchbarComponent
  ],
  schemas: [CUSTOM_ELEMENTS_SCHEMA]
})
export class SharedModule { }
