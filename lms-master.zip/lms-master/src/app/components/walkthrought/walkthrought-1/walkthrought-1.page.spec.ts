import { CUSTOM_ELEMENTS_SCHEMA } from '@angular/core';
import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { Walkthrought1 } from './walkthrought-1.page';

describe('Walkthrought1', () => {
  let component: Walkthrought1;
  let fixture: ComponentFixture<Walkthrought1>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [Walkthrought1],
      schemas: [CUSTOM_ELEMENTS_SCHEMA],
    })
      .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(Walkthrought1);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
